# TAA 參考資料收件清單

等待使用者通知收件完成後再匯入 Wiki。此資料夾目前保存來源連結。原文 PDF 與網頁副本尚未下載。

- Le et al. (2019) — Ankle Arthritis — [PubMed](https://pubmed.ncbi.nlm.nih.gov/35097330/) · [PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC8500397/)
- Ewalefo et al. (2018) — Management of Posttraumatic Ankle Arthritis: Literature Review — [PubMed](https://pubmed.ncbi.nlm.nih.gov/30327933/) · [PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC6220012/)
- Li et al. (2024) — Total ankle replacement versus ankle fusion for end-stage ankle arthritis: A meta-analysis — [PubMed](https://pubmed.ncbi.nlm.nih.gov/38607239/) · [出版商](https://doi.org/10.1177/10225536241244825)
- Colò et al. (2025) — Five decades of total ankle replacement: from early failures to fourth-generation innovations and future priorities — [PubMed](https://pubmed.ncbi.nlm.nih.gov/41460300/) · [PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC12748299/)
- Hershfeld et al. (2026) — Total Ankle Arthroplasty: A Comparative Review of Surgical Approaches and Outcomes — [PubMed](https://pubmed.ncbi.nlm.nih.gov/42299372/) · [PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC13259566/)
- Orthobullets — Ankle Arthritis — [原始網頁](https://www.orthobullets.com/foot-and-ankle/7037/ankle-arthritis)
- Orthobullets — Total Ankle Arthroplasty — [原始網頁](https://www.orthobullets.com/foot-and-ankle/12133/total-ankle-arthroplasty)

## 經確認補充的來源

- S08 [Johnston County Osteoarthritis Project](https://pmc.ncbi.nlm.nih.gov/articles/PMC5468490/)
- S09 [Zimmer Biomet｜Trabecular Metal™ Total Ankle 歐洲版 06.02227.012](https://assets.ctfassets.net/rc4arfpyhdpw/3g0u5tBORhAVrJJfv2rMYP/b9cc9f6311ad73e03d1055ee98907edf/tm_total_ankle_surgical_techni__1_.pdf)
- S10 [Stryker｜INBONE II 原廠手冊 AP-015741C](https://assets-global.website-files.com/655778436baf91b186425b5a/65f351081d314d1a30ffcc53_AP-015741C%20Inbone%20II_EN.pdf)
