# TAA Wiki 維護規範

先確認來源再匯入。原始入口保存在 reference。Wiki 來源卡標明實際查閱的是全文、摘要或教學網頁。更新主題頁、索引與日誌。依卡片生成逐頁稿，檢查研究分母、終點、分期與型號。遇證據不足回來源層，頁面問題回逐頁稿。

[Karpathy LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)