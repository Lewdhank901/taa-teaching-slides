# TAA LLM Wiki

## 主題

- [創傷後踝關節退化](topics/1.md) · S01、S02
- [踝 OA 與創傷的關係](topics/2.md) · S01、S02、S08
- [負重影像與改良 Takakura](topics/3.md) · S01、S06
- [誰適合評估 TAA？](topics/4.md) · S01、S02、S07
- [TAA 與 fusion](topics/5.md) · S01、S03、S07
- [植入物設計與入路](topics/6.md) · S04、S05、S07、S09、S10
- [病例討論](topics/7.md) · S01、S03、S06、S07

## 來源

- [Le 等｜Ankle Arthritis](sources/S01.md)
- [Ewalefo 等｜Management of Posttraumatic Ankle Arthritis](sources/S02.md)
- [Li 等｜TAA versus ankle fusion: meta-analysis](sources/S03.md)
- [Colò 等｜Five decades of total ankle replacement](sources/S04.md)
- [Hershfeld 等｜A Comparative Review of Surgical Approaches and Outcomes](sources/S05.md)
- [Orthobullets｜Ankle Arthritis](sources/S06.md)
- [Orthobullets｜Total Ankle Arthroplasty](sources/S07.md)

- [Johnston County Osteoarthritis Project](sources/S08.md)
- [Zimmer Biomet｜Trabecular Metal™ Total Ankle 歐洲版 06.02227.012](sources/S09.md)
- [Stryker｜INBONE II 原廠手冊 AP-015741C](sources/S10.md)

[日誌](log.md)