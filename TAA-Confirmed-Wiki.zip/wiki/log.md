## [2026-11-21] ingest | S01

[Le 等｜Ankle Arthritis](sources/S01.md) · PMC 全文。

## [2026-11-21] ingest | S02

[Ewalefo 等｜Management of Posttraumatic Ankle Arthritis](sources/S02.md) · PubMed 摘要。

## [2026-11-21] ingest | S03

[Li 等｜TAA versus ankle fusion: meta-analysis](sources/S03.md) · PubMed 摘要。

## [2026-11-21] ingest | S04

[Colò 等｜Five decades of total ankle replacement](sources/S04.md) · PMC 全文入口。

## [2026-11-21] ingest | S05

[Hershfeld 等｜A Comparative Review of Surgical Approaches and Outcomes](sources/S05.md) · PMC 全文。

## [2026-11-21] ingest | S06

[Orthobullets｜Ankle Arthritis](sources/S06.md) · 教學網頁。

## [2026-11-21] ingest | S07

[Orthobullets｜Total Ankle Arthroplasty](sources/S07.md) · 教學網頁。

## [2026-11-21] query / lint

查索引後將 7 筆來源對應至 7 個教學主題。證據核對時區分創傷後病因占比與一般人口盛行率，並依分期表確認 IIIa／IIIb 的接觸位置。Li 等僅依摘要摘錄可核對的合併結果。
## [2026-11-21] ingest | S08–S10

使用者確認補充來源範圍後，加入社區影像性踝 OA 研究及兩套原廠資料。檢查分母、影像定義、產品型號與手冊版本後，更新疾病負擔及植入物頁。
